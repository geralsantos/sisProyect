@extends('layouts.admin')


@section('contenido')

<div class="container">
  <h3>index proveedor</h3>  
   
   
    
</div>
 


@endsection