
@extends('layouts.admin')
@section('contenido')

<div class="container">
  {!!Form::open(array('url'=>'compras/ingresos/submit','method'=>'POST','autocomplete'=>'off','role'=>'CREATE','id'=>'form-create','name'=>'form-create', 'enctype'=>'multipart/form-data'))!!}
<div class="row">
  <!--div class="form-group row col-sm-10">

    <label class="col-xs-2 col-form-label"><p>
      Seleccione Imagen
    </p> </label>
    <div class="col-sm-10">
    <input class="form-control" type="file" name="file" id="file" accept="image/*" value="" >
    <input type="hidden" name="imagen" id="imagen" value="">
    <input type="hidden" name="_i" id="_i" value="2">
      <img id="img" src="{{asset('images/no-foto.png')}}" alt="" />
    </div>
  </div-->

  <div class="form-group row col-sm-10">
    <label class="col-xs-2 col-form-label" for="tipo_persona"><p> Tipo Persona: </p></label>
      <div class="col-sm-10 tipo_persona">
        <input type="text" class="form-control" name="tipo_persona" id="tipo_persona" value="{{$tabla_ingreso->tipo_persona}}">

      </div>
</div>
  <div class="form-group row col-sm-10">
       <label class="col-xs-2 col-form-label" for="Persona"> <p>Persona: </p></label>

          <div class="col-sm-10 Persona">

            <input type="text" class="form-control" name="Persona" id="Persona" value="{{$tabla_ingreso->proveedor}}">

              <label class="control-label Persona"></label>

           </div>
        </div>
        <div class="form-group row col-sm-10">
         <label class="col-xs-2 col-form-label" for="tipo_comprobante"><p> Comprobante: </p></label>
           <div class="col-sm-10 tipo_comprobante">
             <input type="text" class="form-control" name="tipo_comprobante" id="tipo_comprobante" value="{{$tabla_ingreso->tipo_comprobante}}">
             <label class="control-label tipo_comprobante"></label>
           </div>
        </div>
  <div class="form-group row col-sm-10">
   <label class="col-xs-2 col-form-label" for="serie_comprobante"><p> Serie Comprobante: </p></label>
     <div class="col-sm-10 serie_comprobante">
       <input type="text" class="form-control" name="serie_comprobante" id="serie_comprobante" value="{{$tabla_ingreso->serie_comprobante}}">
       <label class="control-label serie_comprobante"></label>
     </div>
  </div>
  <div class="form-group row col-sm-10">
     <label class="col-xs-2 col-form-label" for="num_comprobante"><p> Num.Comprobante: </p></label>
      <div class="col-sm-10 num_comprobante">
         <input type="number" class="form-control" name="num_comprobante" id="num_comprobante" value="{{$tabla_ingreso->num_comprobante}}" >
         <label class="control-label num_comprobante"></label>

      </div>
  </div>
  <div class="form-group row col-sm-10">
    <label class="col-xs-2 col-form-label" for="fecha_hora"><p> Fecha emitida: </p></label>
      <div class="col-sm-10 fecha_hora">
           <input type="text" class="form-control" name="fecha_hora" id="fecha_hora" value="{{$tabla_ingreso->fecha_hora}}">
           <label class="control-label fecha_hora"></label>

       </div>
  </div>
  <div class="form-group row col-sm-10">
      <label class="col-xs-2 control-label" for="impuesto"> <p>Impuesto: </p></label>
        <div class="col-sm-10 impuesto">
          <input type="number" class="form-control" name="impuesto" id="impuesto" value="{{$tabla_ingreso->impuesto}}" data-toggle="tooltip" data-placement="right" title="" data-original-title="Se aplica al Total de la Venta">
         <label class="control-label impuesto"></label>

        </div>
  </div>




    {!!Form::close()!!}
    <div class="form-group row col-sm-10">
      <div class="col-sm-10 pull-right">
      <a href="{{route('compras.ingresos.index')}}"> <input type="button" id="return" class="btn btn-warning" name="return"  value="Volver" /></a>
        </div>

    </div>
    <style>
      .progress{
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, .5) url("{{asset('img/progress.gif')}}") no-repeat 50%;
        background-size: 70px 70px;

      }
    </style>
<div class="progress" style="display:none">

</div>
</div>
</div>

@endsection
@section('scripts')

@endsection
