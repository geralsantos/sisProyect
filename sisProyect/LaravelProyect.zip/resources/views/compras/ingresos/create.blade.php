@extends('layouts.admin')
@section('contenido')

<h3>Agregar Ingresos de nuevo Articulo</h3>

<div class="row">
   
   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
       <div class="form-group">
          <select  name="proveedor"  id="proveedor" class="selectpicker"  data-live-search="true">
        
           @foreach($proveedor as $prov)
           <option value="{{$prov->idpersona}}">{{$prov->nombre}}</option>
           @endforeach           
           
      
        </select>
</div>

 
   </div>
   
 
</div>
 
 
@endsection