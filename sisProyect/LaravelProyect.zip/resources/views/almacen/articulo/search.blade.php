@extends('layouts.admin')
@section('contenido')

<h3>articulo x search</h3>


@endsection