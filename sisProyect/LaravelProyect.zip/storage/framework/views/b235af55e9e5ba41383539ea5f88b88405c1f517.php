<?php $__env->startSection('contenido'); ?>
 <div class="container">

<div class="row">
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
            <h3> Agregar un nuevo Ingreso
            <a href="<?php echo e(url('compras/ingresos/create')); ?>"><button class="btn btn-success">Nuevo</button></a>
            </h3>

        </div>


    </div>

    <div class="row">


     <div class="container">



                   <div class="table-responsive col-lg-12 col-md-11 col-sm-10 col-xs-9">
                            <table style="width:100%;max-width:1200px;margin:15 auto;text-align:center" id="myTable" class="table table-hover table-striped">

                              <thead>


                                <th style="text-align:center">#</th>
                                <th style="text-align:center">Proveedor</th>
                                <th style="text-align:center">Comprobante</th>
                                <th style="text-align:center">Fecha</th>
                                <th style="text-align:center">Impuesto</th>
                                <th style="text-align:center">Estado</th>
                                <th style="text-align:center">Opciones</th>

                             </thead>
                              <tbody>
                                  
                              </tbody>





                         </table>


                                 </div>



                   </div>
        </div>
        <?php echo Form::open(['route'=>['compras.ingresos.destroy',':INGRESO_ID'],'method'=>'DELETE','autocomplete'=>'off','role'=>'DELETE','id'=>'form-delete']); ?>

        <?php echo Form::close(); ?>

        </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

 <script src="<?php echo e(asset('js/ingresos/ajax_ingresos.js')); ?>"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>