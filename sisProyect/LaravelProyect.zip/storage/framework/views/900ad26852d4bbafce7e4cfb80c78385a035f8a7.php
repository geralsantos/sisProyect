 <?php foreach($categorys as $cat): ?>
                    <tr data-id='<?php echo e($cat->idcategoria); ?>' data-name='<?php echo e($cat->nombre); ?>'>
                        <td>
                          
                            <input type="checkbox" >
                        </td>
                        <td>
                            <?php echo e($cat->idcategoria); ?>

                        </td>
                        <td>
                            <?php echo e($cat->nombre); ?>

                        </td>
                        <td>
                            <?php echo e($cat->descripcion); ?>

                        </td>
                        <td>
                        <a href="<?php echo e(URL::action('CategoriaController@edit',$cat->idcategoria)); ?>"><button class="btn btn-info btn-edit" data-toggle="modal" data-target="#myModal">Editar</button></a>
                        <a href=""><button class="btn btn-danger btn-delete">Eliminar</button></a>
                        </td>
                    </tr>
  <?php endforeach; ?>
                    
                   