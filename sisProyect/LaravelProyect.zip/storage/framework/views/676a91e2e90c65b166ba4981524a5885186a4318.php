<div id="ajax_login">
                
             <?php if(count($errors)>0): ?>
                       <?php foreach($errors->get($key) as $e): ?>
                       <p> <?php echo e($e); ?></p>
                    <?php endforeach; ?>
                    <?php endif; ?>
                       </div>  