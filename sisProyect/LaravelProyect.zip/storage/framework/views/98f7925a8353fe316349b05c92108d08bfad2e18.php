
                      <?php foreach($categorias as $cat): ?>
                    <tr data-id='<?php echo e($cat->idcategoria); ?>' data-name='<?php echo e($cat->nombre); ?>'>

                        <td>
                            <?php echo e($cat->idcategoria); ?>

                        </td>
                        <td>
                            <?php echo e($cat->nombre); ?>

                        </td>
                        <td>
                            <?php echo e($cat->descripcion); ?>

                        </td>
                        <td width="300px">
                        <a href="<?php echo e(URL::action('CategoriaController@edit',$cat->idcategoria)); ?>"><button class="btn btn-info btn-edit" data-toggle="modal" data-target="#myModalEdit">Editar</button></a>
                        <a href=""><button class="btn btn-danger btn-delete">Eliminar</button></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
