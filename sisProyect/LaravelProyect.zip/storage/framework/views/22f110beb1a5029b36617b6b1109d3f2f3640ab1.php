<?php $__env->startSection('contenido'); ?>

<h3>Agregar Ingresos de nuevo Articulo</h3>

<div class="row">
   
   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
       <div class="form-group">
          <select  name="proveedor"  id="proveedor" class="selectpicker"  data-live-search="true">
        
           <?php foreach($proveedor as $prov): ?>
           <option value="<?php echo e($prov->idpersona); ?>"><?php echo e($prov->nombre); ?></option>
           <?php endforeach; ?>           
           
      
        </select>
</div>

 
   </div>
   
 
</div>
 
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>