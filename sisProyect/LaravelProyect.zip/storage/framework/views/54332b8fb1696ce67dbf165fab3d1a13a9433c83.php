<?php $__env->startSection('contenido'); ?>
   <div class="container">
    <h3>index.php</h3>
    <div class="row">
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
            <h3>Listado de Articulos <a href="<?php echo e(url('almacen/articulo/create')); ?>"><button class="btn btn-success">Nuevo</button></a> </h3>
        </div>


    </div>


    <div class="row">

      <div id="myModalEdit" class="modal fade" role="dialog">
          <div class="modal-dialog modal-lg">

    <!-- Modal content-->
            <div class="modal-content" >
              <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" > Categoria</h4>
              </div>

              <style>
                #form-update section ul li{
                 list-style: none;

                }
                .modal-backdrop
                  {
                      opacity:0 !important;
                  }

              </style>
              <?php echo Form::open(['route'=>['almacen.articulo.update',':ARTICLE_ID'],'method'=>'PATCH','autocomplete'=>'off','role'=>'UPDATE','id'=>'form-update','class'=>'form-horizontal','name'=>'form-update', 'enctype'=>'multipart/form-data']); ?>




          <div class="modal-body" data-id="modal-edit">
            <style>
              .modal-row{
                padding-left: 12%;
              }
            </style>
            <div class="row modal-row">

              <div class="form-group row col-sm-10">

                <label class="col-xs-2 col-form-label" class="control-label">Seleccione Imagen</label>
                <div class="col-sm-10">
                <input class="form-control" type="file" name="file" id="file" accept="image/*" value="" >
                <input type="hidden" name="imagen" id="imagen" value="">
                <input type="hidden" name="_i" id="_i" value="">
                  <!--img id="img" src="<?php echo e(asset('images/no-foto.png')); ?>" alt="" /-->
                </div>
              </div>
              <div class="form-group row col-sm-10">
                <label class="col-xs-2 col-form-label" for="Categoria"> <p>Categoria: </p></label>

                  <div class="col-sm-10 Categoria">

                    <select class="Categoria form-control" id="Categoria" name="Categoria" data-toggle="tooltip" data-placement="top" title="" data-original-title="Seleccione su Categoria">
                      <option value=""> Seleccione Categoria</option>

                       <?php foreach($categorias as $cat): ?>
                       <option value="<?php echo e($cat->idcategoria); ?>"> <?php echo e($cat->nombre); ?> </option>
                       <?php endforeach; ?>

                    </select>
                     <label class="control-label Categoria"></label>

                   </div>
                   <label class="col-xs-2 col-form-label" for="Marca"> <p>Marca: </p></label>

                      <div class="col-sm-10 Marca">

                          <select class="Marca form-control" id="Marca" name="Marca" data-toggle="tooltip" data-placement="top" title="" data-original-title="Seleccione su Marca">
                            <option value=""> Seleccione Marca </option>

                             <?php foreach($marcas as $mar): ?>
                             <option value="<?php echo e($mar->idmarca); ?>"> <?php echo e($mar->nombre_marca); ?> </option>
                             <?php endforeach; ?>

                          </select>
                          <label class="control-label Marca"></label>

                       </div>
                    </div>
                    <div class="form-group row col-sm-10">
                     <label class="col-xs-2 col-form-label" for="Codigo"><p> Codigo: </p></label>
                       <div class="col-sm-10 Codigo">
                         <input type="text" class="form-control" name="Codigo" id="Codigo" value="">
                         <label class="control-label Codigo"></label>
                       </div>
                    </div>
              <div class="form-group row col-sm-10">
               <label class="col-xs-2 col-form-label" for="Articulo"><p> Articulo: </p></label>
                 <div class="col-sm-10 Articulo">
                   <input type="text" class="form-control" name="Articulo" id="Articulo" value="">
                   <label class="control-label Articulo"></label>
                 </div>
              </div>
              <div class="form-group row col-sm-10">
                 <label class="col-xs-2 col-form-label" for="Stock"><p> Stock: </p></label>
                  <div class="col-sm-10 Stock">
                     <input type="number" class="form-control" name="Stock" id="Stock" value="" data-toggle="tooltip" data-placement="right" title="" data-original-title="Indique cantidad">
                     <label class="control-label Stock"></label>

                  </div>
              </div>
              <div class="form-group row col-sm-10">
                <label class="col-xs-2 col-form-label" for="Stock_min"><p> Stock Minimo: </p></label>
                  <div class="col-sm-10 Stock_min">
                       <input type="number" class="form-control" name="Stock_min" id="Stock_min" value="" data-toggle="tooltip" data-placement="right" title="" data-original-title="Indique Alerta de Escasez de Articulo">
                       <label class="control-label Stock_min"></label>

                   </div>
              </div>
              <div class="form-group row col-sm-10">
                  <label class="col-xs-2 control-label" for="Descripcion"> <p>Descripcion: </p></label>
                    <div class="col-sm-10 Descripcion">
                     <textarea  style="max-width:100%;max-height:60px" type="text" rows="3" id="Descripcion" name="Descripcion" class="form-control" value="" ></textarea>
                     <label class="control-label Descripcion"></label>

                    </div>
              </div>
              <div class="form-group row col-sm-10">
                  <label class="col-xs-2 col-form-label" for="Venta"><p> Prec. Venta: </p></label>
                    <div class="col-sm-10 Venta">
                      <input type="number" class="form-control" name="Venta" id="Venta" value="" data-toggle="tooltip" data-placement="right" title="" data-original-title="Indique a Cuanto se Vende">
                      <label class="control-label Venta"></label>

                    </div>
              </div>
              <div class="form-group row col-sm-10">
                  <label class="col-xs-2 col-form-label" for="Compra"><p> Prec. Compra: </p></label>
                      <div class="col-sm-10 Compra">
                        <input class="form-control" type="number" name="Compra" id="Compra" value="" data-toggle="tooltip" data-placement="right" title="" data-original-title="Indique a Cuanto se Compró">
                        <label class="control-label Compra"></label>

                      </div>
              </div>
              <script>
                      $(document).on('ready', function() {
                          $("#file").fileinput({
                            language: 'es',
                              browseClass: "btn btn-primary btn-block",
                              showCaption: false,
                              showRemove: false,
                              showUpload: false,
                              previewFileType: "image",
                               allowedFileExtensions: ["jpg", "tiff","tif", "png", "jpeg","gif","bmp","ico"],
                               previewClass: "bg-warning",
                              initialPreview: [
                                  "<?php echo e(asset('images/no-foto.png')); ?>"

                        ],
                        initialPreviewAsData: true, // identify if you are sending preview data only and not the raw markup
                        initialPreviewFileType: 'image' // image is the default and can be overridden in config below

                              /*  initialPreview: [
                                  "<?php echo e(asset('images/no-foto.png')); ?>"
                                 ],
                              initialPreviewAsData: true,
                              initialPreviewConfig: [
                                  {caption: "Earth.jpg", size: 1218822, width: "120px", key: 2, showZoom: false}
                                ]*/

                                });
                            });
              </script>

              <!--input type="file" name="file" id="file" -->

              <!--input type="hidden" name="fake_image" id="fake_image" value=""-->
              <!--progress id="prog" max="100" value="0" style="display:none;"></progress-->

            </div>

          </div>

                 <?php echo Form::close(); ?>



                  <div class="modal-footer">

                        <button type="button" data-id="idarticulo" class="btn btn-success btn-update-articulo">Aceptar</button>
                        <button type="reset" id="cancelModal" class="btn btn-warning" data-dismiss="modal">Cancelar</button>

                 </div>
                        <style>
                          .progress{
                            position: absolute;
                            top: 0;
                            left: 0;
                            width: 100%;
                            height: 100%;
                            background: rgba(255, 255, 255, .5) url("<?php echo e(asset('img/progress.gif')); ?>") no-repeat 50%;
                            background-size: 70px 70px;

                          }
                        </style>
                    <div class="progress" style="display:none">

                    </div>
      </div>

       </div>

      </div>




      <div class="container">


        <style>
          tbody .cls_precio_venta:before, .cls_precio_compra:before{
            content: "S/.";
          }
        </style>
          <div class="table-responsive col-lg-12 col-md-11 col-sm-10 col-xs-9">
                   <table style="width:100%;max-width:1200px;margin:15 auto;text-align:center" id="myTable" class="table table-striped">

                     <thead>


                       <th style="text-align:center">Codigo</th>
                       <th style="text-align:center">Nombre</th>
                       <th style="text-align:center">Stock</th>
                       <th style="text-align:center">Stock Min</th>
                       <th style="text-align:center">Prec. Venta</th>
                       <th style="text-align:center;width:120px;">Prec. Compra</th>
                       <th style="text-align:center">Opciones</th>

                    </thead>





                </table>


                        </div>

                   </div>

            </div>


    <?php echo Form::open(['route'=>['almacen.articulo.destroy',':ARTICLE_ID'],'method'=>'DELETE','autocomplete'=>'off','role'=>'DELETE','id'=>'form-delete']); ?>

    <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

        <script src="<?php echo e(asset('js/articulo/articulo.js')); ?>">

        </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>