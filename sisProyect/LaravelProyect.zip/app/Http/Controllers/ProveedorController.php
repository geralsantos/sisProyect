<?php

namespace app\Http\Controllers;

use Illuminate\Http\Request;

use app\Http\Requests;

class ProveedorController extends Controller
{
    //
    
    public function index(Request $request){
    
        return view('compras.proveedor.index');
        
    }
}
