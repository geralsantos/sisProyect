<?php

namespace app\Http\Controllers;

use Illuminate\Http\Request;

use app\Http\Requests;
use DB;
use Response;
use Validator;
use Illuminate\Support\Facades\Redirect;
use app\Http\Controllers\Controller;
use app\Ingresos;

class IngresosController extends Controller
{
    //
    public function detail (Request $request,$id){

        //$param = trim($request->get('id'));
      $tabla_detalle = DB::table('detalle_ingreso')
            ->join('ingreso','detalle_ingreso.idingreso','=','ingreso.idingreso')
            ->join('articulo','detalle_ingreso.idarticulo','=','articulo.idarticulo')
            ->select('ingreso.idingreso as idingreso','articulo.nombre as articulo','detalle_ingreso.cantidad as cantidad','detalle_ingreso.precio_compra as precio_compra','detalle_ingreso.precio_venta as precio_venta')
            ->where('detalle_ingreso.idingreso','=',$id)
            ->get();

     $tabla_ingreso = DB::table('ingreso')
            ->join('persona','persona.idpersona','=','ingreso.idproveedor')
            ->join('detalle_ingreso','detalle_ingreso.idingreso','=','ingreso.idingreso')
            ->select('persona.tipo_persona as tipo_persona','persona.nombre as proveedor','ingreso.tipo_comprobante as tipo_comprobante','ingreso.serie_comprobante as serie_comprobante','ingreso.num_comprobante as num_comprobante','ingreso.fecha_hora as fecha_hora','ingreso.impuesto as impuesto',DB::raw('sum(detalle_ingreso.cantidad * detalle_ingreso.precio_compra) as total'))
            ->where('ingreso.idingreso','=',$id)->first();

       /* $result = array(
                'detalle'=>$table_detalle
        //DB::raw('sum(detalle_ingreso.cantidad * detalle_ingreso.precio_compra) as total'))
        );*/
      //  return  view('compras.ingresos.detalle_ingreso',['detalle_ingreso'=>$result]);
         return view('compras.ingresos.detalle_ingreso',['tabla_detalle'=>$tabla_detalle,'tabla_ingreso'=>$tabla_ingreso]);

   }
    public function index(Request $request){

    if($request){

        $ingreso = DB::table('ingreso')->join('persona','ingreso.idproveedor','=','persona.idpersona')
                      ->select('ingreso.idingreso as idingreso','persona.nombre as nombre',
                               DB::raw("CONCAT(ingreso.tipo_comprobante ,': ', ingreso.serie_comprobante,'-', ingreso.num_comprobante) as tipo_comprobante"),
                               'ingreso.fecha_hora as fecha_hora',
                               'ingreso.impuesto as impuesto','ingreso.estado as estado')
                               ->where('persona.tipo_persona','=',"proveedor")
                      ->get();



    }
return view('compras.ingresos.index',["ingresos"=>$ingreso]);

    }

    public function create(Request $request){

      //  $proveedor = DB::table('persona')->where('tipo_persona','=','proveedor')->get();

      //  return view('compras.ingresos.create',["proveedor"=>$proveedor]);
    }

    public function store(Request $request)
    {
        //
    }

    public function update(Request $request)
    {
        //
    }
    public function destroy(Request $request,$id)
    {
        //
        $ingreso=Ingresos::findOrFail($id);
          $ingreso->estado='Cancelado';
          $ingreso->update();
          //return Redirect::to('almacen/categoria');
          $message ='El Ingreso '. $ingreso->tipo_comprobante .':'. $ingreso->serie_comprobante.'-'.$ingreso->num_comprobante.' fue eliminado.';

         if ($request){


          return Response::json([
                       'message' =>$message


          ]);
          }
    }
  /*  public function show(Request $request){

        //return "das";

    }*/

   public function edit($id){


       $ingreso = Ingresos::where('idingreso','=',$id)->where('estado','=','Activo')->count();
       $ingreso = $ingreso > 0 ?  Response::json([ 'success'=>true,'ingreso'=>Ingresos::findOrFail($id) ]) :  Response::json([ 'success'=>false]);

       return $ingreso;

   }



}
