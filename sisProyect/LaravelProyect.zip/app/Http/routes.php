<?php
use Yajra\Datatables\Facades\Datatables;
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('layouts/admin');
});

//---------------------------------------Categoria-----------------------------------------------------//
Route::match(array('GET','POST'),'almacen/categoria/submit','CategoriaController@store');
//Route::match(array('GET','POST'),'almacen/categoria/update/{id}','CategoriaController@update');
Route::match(array('GET','POST'),'almacen/categoria/dataload',function(){
    return Datatables::eloquent(app\Categoria::query()->where("condicion","=","1")->orderBy("idcategoria","desc"))->make(true);
    //return Datatables::queryBuilder(DB::table('categoria')->where("condicion","=","1"))->make(true);

});
Route::match(array('GET','POST'),'almacen/categoria/{id}','CategoriaController@update');

Route::match(array('GET','POST'),'almacen/categoria/edit/{id}','CategoriaController@edit');
Route::get('almacen/categoria/create','CategoriaController@create');
Route::resource('almacen/categoria','CategoriaController');
Route::resource('compras/proveedor','ProveedorController');

//---------------------------------------Articulo-----------------------------------------------------//

Route::match(array('GET','POST'),'almacen/articulo/dataload',function(){
  return Datatables::eloquent(app\Articulo::query()->where("estado","=","Activo")->orderBy("idarticulo","desc"))->make(true);
   //return Datatables::queryBuilder(DB::table('articulo')->where("estado","=","Activo"))->make(true);

});
Route::match(array('GET','POST'),'almacen/articulo/submit','ArticuloController@store');

Route::match(array('GET','POST'),'almacen/articulo/edit/{id}','ArticuloController@edit');
Route::resource('almacen/articulo/create','ArticuloController@create');
Route::resource('almacen/articulo','ArticuloController');

//---------------------------------------Ingresos-----------------------------------------------------//
Route::match(array('GET','POST'),'compras/ingresos/dataload',function(){
  return Datatables::eloquent(
        app\Ingresos::query()->join('persona','ingreso.idproveedor','=','persona.idpersona')
                      ->select('ingreso.idingreso as idingreso','persona.nombre as nombre',
                               DB::raw("CONCAT(ingreso.tipo_comprobante ,': ', ingreso.serie_comprobante,'-', ingreso.num_comprobante) as tipo_comprobante"),
                               'ingreso.fecha_hora as fecha_hora',
                               'ingreso.impuesto as impuesto','ingreso.estado as estado')
                               ->where('persona.tipo_persona','=',"proveedor"))->make(true);
   //return Datatables::queryBuilder(DB::table('articulo')->where("estado","=","Activo"))->make(true);

});
Route::get("compras/ingresos/detalle/{id}","IngresosController@detail");
Route::match(array('GET','POST'),'compras/ingresos/edit/{id}','IngresosController@edit');

Route::resource('compras/ingresos','IngresosController');
