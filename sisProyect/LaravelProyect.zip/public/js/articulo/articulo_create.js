function __(id){

    return document.getElementById(id);

}

$(document).ready(function(){

  function progress(display){
  $(".container .progress").css("display",display);

  }


  //-----  Boton create(actualiza los campos);--------//
  $(document).on('click','#form-create .btn-create-articulo',function(e){
    // el btn create tiene el atributo data-id
    //var form = $('#form-create');
    $form = $('#form-create');
    uploadImage($form);

      function uploadImage($form){
        var form = $('#form-create');
        var url = form.attr('action');

        var formdata = new FormData(document.forms.namedItem("form-create"));
        var connect = new XMLHttpRequest();

        connect.onreadystatechange = function(){
            progress("none");
           if (connect.readyState==4 && connect.status==200) {

              var Data = JSON.parse(connect.responseText);
              if (Data.success) {
                var error = $(".kv-fileinput-error").html();
                if (error) {

                  swal("Información!", "Archivo no Permitido!, Seleccione un formato de Imagen", "warning");

                }else{
                $('#form-create .row').find(".form-group").children("div").removeClass('has-error');
                $('#form-create .row').find(".form-group").children("div").find("label").html("");

                     swal("Genial!", "Registro Creado con Exito!", "success");
                      $('#return').click();
                    }
                }else{

                 $('#form-create .row').find(".form-group").children("div").removeClass('has-error');
                 $('#form-create .row').find(".form-group").children("div").find("label").html("");

                   $.each(Data.error,function(index,error){
                     $('#form-create .row').find(".form-group").children("."+index+"").addClass('has-error');
                     $('#form-create .row').find(".form-group").children("."+index+"").find("label").html(error);

                 });

                }


             }else if(connect.readyState!=4){
                progress("block")
             }

            }
            connect.open('post',url);
            connect.send(formdata);




  }

           e.preventDefault();
    });
  //-----  Boton create(actualiza los campos);--------//




});
